import Home from "@/components/screens/home/Home";
import styles from "./Home.module.scss";

export default function HomePage() {
  return <Home />;
}
